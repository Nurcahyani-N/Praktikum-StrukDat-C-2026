katalog = [ {'merk': 'Samsung', 'tipe': 'S23', 'sn': 'SAM01', 'stok':  2}, {'merk': 'Oppo', 'tipe': 'Reno 10', 'sn': 'OPP01', 'stok': 5} ] 

sn_target
jumlah_tambah

update_stok = (katalog, sn_target, jumlah_tambah)

daftar_merk = {}